import { Router, Request, Response } from 'express';
import { PersonService } from '../services/person.service.js';
import { SnapshotService } from '../services/snapshot.service.js';
import { InteractionService } from '../services/interaction.service.js';
import { statbateClient } from '../api/statbate/client.js';
import { normalizeMemberInfo, normalizeModelInfo } from '../api/statbate/normalizer.js';
import { logger } from '../config/logger.js';

const router = Router();

/**
 * POST /api/lookup
 * Main lookup endpoint for the home page
 */
router.post('/', async (req: Request, res: Response) => {
  try {
    const {
      username,
      role,
      pastedText,
      includeStatbate = false,
      dateRange, // { start: string, end: string } in "YYYY-MM-DD HH:mm:ss" format
      comparisonDateRange, // Optional second date range for comparison
      // includeMyRoomData = false,
    } = req.body;

    if (!username && !pastedText) {
      return res.status(400).json({ error: 'username or pastedText required' });
    }

    // Extract usernames from pasted text if provided
    let usernames: string[] = [];
    if (pastedText) {
      // Simple extraction: split by whitespace and filter valid usernames
      const extracted = pastedText.match(/\b[a-zA-Z0-9_]+\b/g) || [];
      usernames = [...new Set(extracted.filter((u: unknown) => typeof u === 'string' && u.length > 2))] as string[];
    }

    if (username) {
      usernames.unshift(username);
    }

    if (usernames.length === 0) {
      return res.status(400).json({ error: 'No valid usernames found' });
    }

    // Save pasted text as interaction if provided
    if (pastedText && username) {
      const person = await PersonService.findOrCreate({
        username: usernames[0],
        role: role || 'UNKNOWN',
      });

      await InteractionService.create({
        personId: person.id,
        type: 'PROFILE_PASTE',
        content: pastedText,
        source: 'manual',
      });
    }

    // Process primary username
    const primaryUsername = usernames[0];
    const person = await PersonService.findOrCreate({
      username: primaryUsername,
      role: role || 'UNKNOWN',
    });

    let latestSnapshot = null;
    let delta = null;
    let statbateApiUrl = null; // Track which API was called
    let memberTips = null; // Store member tips data

    // Fetch Statbate data if requested
    if (includeStatbate) {
      try {
        // Try as MODEL first, then as VIEWER if MODEL fails
        let statbateDataFetched = false;

        // Determine which role to try based on:
        // 1. Explicit role from request (user preference)
        // 2. Person's existing role from database
        // 3. Default to trying MODEL first
        const effectiveRole = role || person.role;
        const isExplicitOverride = !!role; // Track if user explicitly requested a specific role

        if (effectiveRole === 'MODEL' || effectiveRole === 'UNKNOWN') {
          try {
            const range = dateRange ? [dateRange.start, dateRange.end] as [string, string] : undefined;
            const rangeQuery = range ? `&range[0]=${encodeURIComponent(range[0])}&range[1]=${encodeURIComponent(range[1])}` : '';
            statbateApiUrl = `https://plus.statbate.com/api/model/chaturbate/${primaryUsername}/info?timezone=UTC${rangeQuery}`;
            const modelData = await statbateClient.getModelInfo('chaturbate', primaryUsername, { range });
            if (modelData) {
              const normalized = normalizeModelInfo(modelData.data);
              const snapshot = await SnapshotService.create({
                personId: person.id,
                source: 'statbate_model',
                rawPayload: modelData.data as unknown as Record<string, unknown>,
                normalizedMetrics: normalized,
              });

              // Only update role if not an explicit override (auto-detection mode)
              if (!isExplicitOverride && modelData.data.rid) {
                await PersonService.update(person.id, { rid: modelData.data.rid, role: 'MODEL' });
              } else if (modelData.data.rid) {
                // Just update rid without changing role
                await PersonService.update(person.id, { rid: modelData.data.rid });
              }

              const deltaResult = await SnapshotService.getDelta(person.id, 'statbate_model');
              latestSnapshot = snapshot;
              delta = deltaResult.delta;
              statbateDataFetched = true;
            }
          } catch (modelError) {
            logger.debug('Not a model or model data unavailable', { username: primaryUsername });
          }
        }

        // Try as VIEWER if not already fetched
        if (!statbateDataFetched && (effectiveRole === 'VIEWER' || effectiveRole === 'UNKNOWN')) {
          try {
            statbateApiUrl = `https://plus.statbate.com/api/members/chaturbate/${primaryUsername}/info?timezone=UTC`;
            const memberData = await statbateClient.getMemberInfo('chaturbate', primaryUsername);
            if (memberData) {
              const normalized = normalizeMemberInfo(memberData.data);
              const snapshot = await SnapshotService.create({
                personId: person.id,
                source: 'statbate_member',
                rawPayload: memberData.data as unknown as Record<string, unknown>,
                normalizedMetrics: normalized,
              });

              // Only update role if not an explicit override (auto-detection mode)
              if (!isExplicitOverride && memberData.data.did) {
                await PersonService.update(person.id, { did: memberData.data.did, role: 'VIEWER' });
              } else if (memberData.data.did) {
                // Just update did without changing role
                await PersonService.update(person.id, { did: memberData.data.did });
              }

              const deltaResult = await SnapshotService.getDelta(person.id, 'statbate_member');
              latestSnapshot = snapshot;
              delta = deltaResult.delta;
              statbateDataFetched = true;

              // Fetch member tips if we have viewer data
              try {
                const range = dateRange ? [dateRange.start, dateRange.end] as [string, string] : undefined;
                memberTips = await statbateClient.getMemberTips('chaturbate', primaryUsername, {
                  range,
                  perPage: 100, // Get up to 100 recent tips
                });

                if (memberTips && memberTips.data.length > 0) {
                  logger.info(`Fetched ${memberTips.data.length} tips for member ${primaryUsername}`);
                }
              } catch (tipsError) {
                logger.debug('Error fetching member tips', { error: tipsError, username: primaryUsername });
              }
            }
          } catch (memberError) {
            logger.debug('Not a member or member data unavailable', { username: primaryUsername });
          }
        }

        if (!statbateDataFetched) {
          logger.warn('No Statbate data found for user', { username: primaryUsername });
        }
      } catch (error) {
        logger.error('Error fetching Statbate data', { error, username: primaryUsername });
      }
    }

    // Get recent interactions
    const interactions = await InteractionService.getByPerson(person.id, { limit: 20 });

    // Get latest interaction
    const latestInteraction = await InteractionService.getLatest(person.id);

    // Handle comparison if requested
    let comparison = null;
    if (comparisonDateRange && latestSnapshot) {
      try {
        const source = latestSnapshot.source as 'statbate_model' | 'statbate_member';

        // Convert string dates to Date objects
        const period1Start = new Date(comparisonDateRange.start);
        const period1End = new Date(comparisonDateRange.end);
        const period2Start = dateRange ? new Date(dateRange.start) : new Date(0);
        const period2End = dateRange ? new Date(dateRange.end) : new Date();

        const comparisonResult = await SnapshotService.compareDateRanges(
          person.id,
          source,
          { start: period1Start, end: period1End },
          { start: period2Start, end: period2End }
        );

        comparison = comparisonResult;
      } catch (error) {
        logger.error('Error computing comparison', { error });
      }
    }

    res.json({
      person,
      latestSnapshot,
      delta,
      interactions,
      latestInteraction,
      extractedUsernames: usernames,
      statbateApiUrl, // Include the actual API URL for debugging
      comparison, // Include comparison data if requested
      memberTips, // Include member tips data if fetched
    });
  } catch (error) {
    logger.error('Lookup error', { error });
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
